﻿namespace Vehicles
{
    public interface IEngine
    {
        public void Run();
    }
}
