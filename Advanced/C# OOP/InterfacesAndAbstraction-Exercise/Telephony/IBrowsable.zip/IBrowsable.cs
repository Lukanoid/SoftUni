﻿namespace Telephony;

public interface IBrowsable
{
    public void Browse(string URL);
}