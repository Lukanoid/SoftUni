﻿namespace Telephony;

public interface ICallable
{
    public void Call(string number);
}